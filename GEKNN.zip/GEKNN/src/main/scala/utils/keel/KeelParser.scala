package utils.keel

import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.ml.linalg.VectorUDT
//import org.apache.spark.ml.feature.LabeledPoint
import org.apache.spark.mllib.linalg
import org.apache.spark.mllib.regression.LabeledPoint
/**
 * Gets the information from the header in order to normalize or parser to LabeledPoint or Array[Double] a data set.
 *
 * @author Jesus Maillo
 */
class KeelParser extends Serializable {

  var conv: Array[Map[String, Double]] = null
  var isCategorical: Array[Boolean] = null
  var numClass: Int = 0
  var numFeatures: Int = 0

  /**
   * Constructor.
   *
   * @param sc SparkContext
   * @param file Path to the file. String.
   */
  def this(sc: SparkContext, file: String) {//this 是辅助构造器，this()为调用主构造器，然后再定义这个this辅助构造器
    this()
    calculateParserFromHeader(sc, file)
  }



  /**
   * Get the labels of a feature or the main class as Array[String].
   *
   * @param str string to parser
   */
  def getLabels(str: String): Array[String] = {
    var result = str.substring(str.indexOf("{") + 1, str.indexOf("}")).replaceAll(" ", "").split(",")
    result
  }

  /**
   * Get the min and max of a feature as a Array[Double].
   *
   * @param str string to parser
   */
  def getRange(str: String): Array[Double] = {//输入的时候就已知了这个维度的最大最小值
    var aux = str.substring(str.indexOf("[") + 1, str.indexOf("]")).replaceAll(" ", "").split(",")
    var result = new Array[Double](2)
    result(0) = aux(0).toDouble
    result(1) = aux(1).toDouble
    result
  }

  /**
   * Calculate the information necessary for parser with function parserToDouble.
   *
   * @param sc The SparkContext
   * @param file path of the header
   */
  def calculateParserFromHeader(sc: SparkContext, file: String) = {
    //Reading header. Each element is a line
    val header = sc.textFile(file)
    var linesHeader = header.collect//以数组的形式返回数据集中的所有元素
    var className = "CLASS"

    //Calculate number of featires + 1 for the class
    numFeatures = 0
    for (i <- 0 to (linesHeader.length - 1)) {
      if (linesHeader(i).toUpperCase().contains("@INPUTS")) {
        numFeatures = linesHeader(i).length - linesHeader(i).replaceAllLiterally(",", "").length + 2//每个单词和逗号都算上了长度，算出总长度-逗号占的长度+2，得到的是输入维度+1的个数
      } else if (linesHeader(i).toUpperCase().contains("@OUTPUTS")) {
        className = linesHeader(i).split(" ")(1).toUpperCase()//得到输出维度的名字
      }
    } //end for

    //Calculate transformation to normalize and erase categorical features
    conv = new Array[Map[String, Double]](numFeatures)
    isCategorical = new Array[Boolean](numFeatures)//Boolean 1（true）或者是0(false)布尔数

    for (i <- 0 to numFeatures - 1) {
      conv(i) = Map()
      isCategorical(i) = false
    }

    var auxParserClasses = 0.0
    var auxNumFeature = 0
    for (i <- 0 to (linesHeader.length - 1)) {
      if (linesHeader(i).toUpperCase().contains("@ATTRIBUTE " + className)) {//如果是class类别的那一列的话
        numClass = linesHeader(i).length - linesHeader(i).replaceAllLiterally(",", "").length + 1//确定一共有多少个类别
        val labelsClasses = getLabels(linesHeader(i)) //Array of String with the labels of the objective variable把这些类别放入一个数组中去，该数组中的元素都是字符型
        //labelsClasses=Array("1","2","3","4","5")
        for (key <- labelsClasses) { //Calculate map for parser label classes，对于每一个类别
          conv(numFeatures - 1) += (key -> auxParserClasses)//此时conv里面是空的，还没有装进去内容，每次都要装进去一个键值对（"1"->0）("2"->1)等等
          isCategorical(auxNumFeature) = true
          auxParserClasses = auxParserClasses + 1
        }
      } else if (linesHeader(i).toUpperCase().contains("[")) { //Real or integer feature，如果是非决策属性的话
        val range = getRange(linesHeader(i)) //Min and max of the feature
        conv(auxNumFeature) += ("min" -> range(0), "max" -> range(1)) //Do the parser for this feature
        isCategorical(auxNumFeature) = false//意思就是这个维度不是决策属性
        auxNumFeature = auxNumFeature + 1 //Increase for the next feature
      } else if (linesHeader(i).toUpperCase().contains("{") && !(linesHeader(i).toUpperCase().contains("@ATTRIBUTE CLASS"))) {
        val labelsClasses = getLabels(linesHeader(i)) //Array String with the labels of the feature
        val size = labelsClasses.length//这个维度总共有多少取值的可能

        //Calculate the increase. If categorical variable only have a value (WTF) it must do 0 and the increase 1. Dont /0
        var inc: Double = 0.0
        if (size == 1) {
          inc = 1.0
        } else {
          inc = 1.0 / (size - 1.0)
        }

        for (i <- 0 to labelsClasses.length - 1) { //Map to parser the label class
          conv(auxNumFeature) += (labelsClasses(i) -> i * inc)
        }
        isCategorical(auxNumFeature) = true

        auxNumFeature = auxNumFeature + 1
      } else if (linesHeader(i).toUpperCase().contains("REAL") && !(linesHeader(i).toUpperCase().contains("@ATTRIBUTE CLASS"))) {
        conv(auxNumFeature) += ("no-bound" -> 0, "no-bound" -> 0) //Do the parser for this feature
        isCategorical(auxNumFeature) = false
        auxNumFeature = auxNumFeature + 1 //Increase for the next feature
      }
    } //end for

  }
//之前的操作结束后，conv是有关所有维度的键值对，决策属性是多少类Map（"1"->0,"2"->1,..）,非决策属性是（"min"->...）,("max"->...)
  /**
   * Parser a line(String) to a Array[Double].
   *
   * @param conv Array[Map] with the information to parser
   * @param line The string to be parsed
   */
  def parserToDouble(line: String): Array[Double] = {
    val size = conv.length//这个size应该是维度的大小，
    var result: Array[Double] = new Array[Double](size)

    //Change the line to Array[String]
    val auxArray: Array[String] = line.split(",")

    //Iterate over the array parsing to double each element with the knowlegde of the header
    for (i <- 0 to size - 1) {
      if (auxArray(i) == "?") {
        result(i) = -1
      } else if (conv(i).contains("min") && conv(i).contains("max") && (conv(i).size == 2)) { //If dictionary have like key (only) min and max is real or integer, else, categorical
        result(i) = (auxArray(i).toDouble - conv(i).get("min").get) / (conv(i).get("max").get - conv(i).get("min").get)
      } else if (conv(i).contains("no-bound")) {
        result(i) = auxArray(i).toDouble
      } else {
        result(i) = conv(i).get(auxArray(i)).get
      }
    }

    result//每一列进行标准化之后的值，决策属性不用标准化，这个函数的输入是一个行文本
  }

  /**
   * Denormalize a double to String.
   *
   * @param pos Position of the Array
   * @param value Value to be parsed
   */
  def denormalizeReal(pos: Int, value: Double): String = {
    var result: String = ""

    if (conv(pos).contains("min") && conv(pos).contains("max") && (conv(pos).size == 2)) { //If dictionary have like key (only) min and max is real or integer, else, categorical
      result = (value * (conv(pos).get("max").get - conv(pos).get("min").get) + conv(pos).get("min").get).toString()
    } else if (conv(pos).contains("no-bound")) {
      result = value.toString()
    }

    result//这个是反标准化，value是标准化之后的值
  }

  /**
   * Parser a line(String) to a LabeledPoint.
   *
   * @param conv Array[Map] with the information to parser
   * @param line The string to be parsed
   */
  def parserToLabeledPoint(line: String): LabeledPoint = {
    var parsed: Array[Double] = parserToDouble(line)
    val featureVector: linalg.Vector = Vectors.dense(parsed.init)
    val label: Double = parsed.last
    val result = LabeledPoint(label+1, featureVector)

    result//前面的维度都是非决策变量，init的意思是取得数组中除了最后一列的全部元素，最后一列的是决策属性
  }

  def parserToLabeledPoint2(line: String): LabeledPoint = {
    val auxArray = line.split(",")
    val size = auxArray.length
    var result = new Array[Double](size-1)
    for (i<- 0 to size - 2){
      result(i)=auxArray(i).toDouble
    }
    val featureVector = Vectors.dense(result)
    val result_1 = LabeledPoint(auxArray(size-1).toDouble,featureVector)
    result_1
  }
  def parserToVector(line: String): linalg.Vector = {
    val auxArray: Array[String] = line.split(",")
    val size = auxArray.size
    var result: Array[Double] = new Array[Double](size)
    for (i <- 0 to size-1) {
      result(i)=auxArray(i).toDouble
    }
    val featureVector: linalg.Vector = Vectors.dense(result)
    featureVector
  }
  /**
   * Parser a line(String) to a Vectors.
   *
   * @param conv Array[Map] with the information to parser
   * @param line The string to be parsed
   */
  def parserToVectors(line: String) = {
    var parsed = parserToDouble(line)
    val result = Vectors.dense(parsed)

    result//这个是把测试数据向量化
  }

  /**
   * Return the number of label from the objective class.
   *
   * @param conv Array[Map] with the information to parser
   * @param line The string to be parsed
   */
  def getNumClassFromHeader(): Int = {
    numClass
  }

  /**
   * Return the number of features.
   */
  def getNumFeaturesFromHeader(): Int = {
    numFeatures - 1
  }

  /**
   * Return structure necessary for parser.
   */
  def getParserFromHeader(): Array[Map[String, Double]] = {
    conv
  }

  /**
   * Return Array[Boolean]. True is a categorical feature. False is not.
   */
  def getIfCategoricalJava(): Array[java.lang.Boolean] = {
    var categoricalJava: Array[java.lang.Boolean] = new Array[java.lang.Boolean](isCategorical.length)
    for (i <- 0 until isCategorical.length) {
      categoricalJava(i) = isCategorical(i)
    }
    categoricalJava
  }

  /**
   * Return Array[Boolean]. True is a categorical feature. False is not.
   */
  def getIfCategorical(): Array[Boolean] = {
    isCategorical
  }

}