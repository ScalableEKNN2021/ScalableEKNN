package org.apache.spark.mllib.classification.LHS_FkNN

import breeze.linalg.{DenseVector, argmax, sum}
import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.rdd._
//import org.apache.spark.ml.feature.LabeledPoint
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg
import breeze.linalg.DenseVector
import breeze.linalg._
import breeze.numerics._
import breeze.stats.distributions.Rand
import scala.collection.mutable.ArrayBuffer
import scala.math
/**
 * @author Jesus Maillo
 */
/**
 * @此处注释掉了下面的内容
 */
//class LHS_FkNN(train: RDD[LabeledPoint], k: Int, distanceType: Int, numClass: Int, numFeatures: Int, numPartitionMap: Int) extends Serializable {
class LHS_FkNN(train: RDD[(Long, LabeledPoint)], k: Int, distanceType: Int, numClass: Int, numFeatures: Int, numPartitionMap: Int) extends Serializable {
  //Trainning set with membership
  var trainFuzzified: RDD[(Long, LabeledPoint, Double)] = null//是一个空的RDD，RDD里面每个元素都是一个Array
  var result: Array[Array[Double]] = new Array[Array[Double]](1)
  def getTrain: RDD[(Long, LabeledPoint)] = train
  def getK: Int = k
  def getDistanceType: Int = distanceType
  def getNumClass: Int = numClass
  def getNumFeatures: Int = numFeatures
  def getNumPartitionMap: Int = numPartitionMap
  def getTrainFuzzified: RDD[(Long, LabeledPoint, Double)] = trainFuzzified
  def getTrainwrong: Array[Array[Double]] = result


  /**
   * @brief Calculate the class membership degree. Train vs train.
   */
  def LHS_Membership(): LHS_FkNN = {
    trainFuzzified = train.repartition(numPartitionMap).mapPartitions(split => knnMembership(split)).cache//cache是考虑内存的消耗，是一个持久化的操作，mapPartitions返回的是一个迭代器
    //split本身也就是一个迭代器
    trainFuzzified.count
    this
  }




  def gamma_learn(train: ArrayBuffer[(Long, LabeledPoint)], neighs: Array[Array[Array[Double]]], S: Array[Double] , X:DenseMatrix[Double] , gamm : Array[Double] , M_1: DenseVector[Double] ): Array[(Long, LabeledPoint, Double)] = {
    val Napp: Int =train.length
    //    println(train(0).features)
    val alpha: Double =0.95
    val maxiter = 201
    val eta = 0.1
    val gain_min: Double = 1e-5
    var ds = Array.fill(k*Napp)(-1.toDouble)
    var is = Array.fill(k*Napp)(-1.toDouble)
    for (i<-0 until Napp){
      for (j <- 0 until k){
        ds(i*k+j)=neighs(i)(j)(0) * neighs(i)(j)(0)
        is(i*k+j)=neighs(i)(j)(2)
      }
    }

    var ds_Matrix= new DenseMatrix[Double](k, Napp, ds)
    var is_Matrix= new DenseMatrix[Double](k, Napp, is)
    val M: Double = M_1.length.toDouble
    for (i<- 0 until Napp){
      var j=1
      while (j < M+1){
        if (S(i) == M_1(j-1)){
          S(i)==j
          j = (M + 1).toInt
        }
        else{
          j = j + 1
        }
      }
    }
    val N = Napp
    val Ident= DenseMatrix.eye[Double](M.toInt)
    val T = DenseMatrix.zeros[Int](M.toInt,N)
    for(i<-0 until N){   T(S(i).toInt-1,i) = 1  }
    val ones = DenseVector.ones[Double](M.toInt)
    var pas: DenseVector[Double] = eta * ones
    val a = 1.2
    val b = 0.8
    val c: Double = 0.5
    var it = 0
    var gain = 1.toDouble
    var P: DenseVector[Double] = new DenseVector[Double](gamm)
    var L  =   gradientds(S,ds_Matrix,is_Matrix,P,alpha)
    val Errcou1 = L._1
    var Dp: Transpose[DenseVector[Double]] = L._2
    var Pp: DenseVector[Double] = P
    var Errcop: Double = Errcou1 + 1
    var gamm_out  = P

    while (gain > gain_min &  it < maxiter ){
      println(it)
        it = it + 1
        L = gradientds(S,ds_Matrix,is_Matrix,P,alpha)
        var Errco = L._1
        var D: Transpose[DenseVector[Double]] = L._2
      if (gain>100000){gain = 1}
      if (Errco > Errcop) {
        P = Pp
        D = Dp
        pas = pas * c
        P = P - pas *:* D.t
      }
      else{
        gain = 0.9 * gain + 0.1 * math.abs(Errcop - Errco)
        Pp = P
        for (i <- 0 until M.toInt){
          if (D(i) * Dp(i) > 0.toDouble & D(i) * Dp(i) == 0.toDouble) {
            pas(i) = a * pas (i)
          }
          else{
            pas (i) = b * pas(i)
          }
        }
        Dp = D
        P = P - pas *:* D.t
        Errcop = Errco
      }
      gamm_out = P
    }
    val trainwith_gamma = new Array[(Long, LabeledPoint, Double)](Napp)
    for (i<- 0 until Napp){
      var j = 1
      while (j < M + 1 ){
        if (S(i)==M_1(j-1)){
          trainwith_gamma(i) = (train(i)._1, train(i)._2, gamm_out(j-1) )
          j = (M+1).toInt
        }
        else{
          j = j + 1
        }
      }
    }
    trainwith_gamma
  }

  /** @breeze 创建的所有向量都是列向量*/
  def gradientds(S: Array[Double], ds_Matrix: DenseMatrix[Double], is_Matrix: DenseMatrix[Double], P : DenseVector[Double],  alpha: Double ): (Double,Transpose[DenseVector[Double]] ) = {
    val N = S.length
    val M: Int = max(S).toInt
    val Ident= DenseMatrix.eye[Double](M)
    val T = DenseMatrix.zeros[Double](M,N)
        for (i<- 0 until N){
          T (  S(i).toInt - 1, i   ) = 1.toDouble
        }
    val gama: DenseVector[Double] = P
    val Ds = DenseVector.zeros[Double](N).t
    var Dsgama= DenseMatrix.zeros[Double](M,N)
    val one_end = DenseMatrix.ones[Double](1,N)
    val one_end2 = DenseMatrix.ones[Double](M,1)
    var mk =  DenseMatrix.vertcat(Dsgama, one_end)
    var mm = mk
    var s_yong = new ArrayBuffer[DenseMatrix[Double]]
    val lamda = (1/M.toDouble)
    for (i <-0 until k){
      var Is_1 = new Array[Double](N)
      for (j<- 0 until N ){
        Is_1(j) = S( is_Matrix(i,j).toInt  )
      }
      val Is = new DenseMatrix[Double](N,1,Is_1)
      val Tk = DenseMatrix.zeros[Double](M,N)
      for (j <- 0 until M){
        val ii= new ArrayBuffer[Int]
        var index_1: Int = 0
        for(o<-Is_1){
          if (o==(j+1).toDouble) {ii.append(index_1)}
          index_1=index_1+1
        }
        if (ii.length>0){
             for (oo<-0 until ii.length){
               Tk(j,ii(oo))=1
             }
        }
      }
      val G = gama *:* gama * one_end *:* Tk
      val gam = sum(G, Axis._0)
      val ss_1 = - gam *:* ds_Matrix(i,::)
      val ss_1_a = new Array[Double](N)
      for (pp<- 0 until N ){
        ss_1_a(pp) = math.exp(ss_1(pp))
      }
      val ss = new DenseMatrix[Double](1, N, ss_1_a)
      val s = alpha * ss
      s_yong.append(s)
      val m1 = Tk *:* (  one_end2 *    s  )
      val m2 = one_end - s
      val m = DenseMatrix.vertcat(m1, m2)
      val mk1: DenseMatrix[Double] = mk(0 to M-1, ::) *:*  (  m(0 to M-1, ::)    + (  one_end2 * m (M,::)   )  ) + m(0 to M-1, ::)*:* (one_end2 * mk(M,::))
      val mk2  = (mk(M, ::) *:* m(M, ::)).t
      val mk3 = mk2.toDenseMatrix
      mk = DenseMatrix.vertcat(mk1, mk3)
//      println(i)
    }
    val Kn: Transpose[DenseVector[Double]] =  sum(mk, Axis._0)
    val one_end3 = DenseMatrix.ones[Double](M+1,1)
    val mkn = mk /:/ ( one_end3 * Kn  )
    val one_end4: DenseVector[Double] = DenseVector.ones[Double](M)
    val Q: DenseMatrix[Double] = mkn(0 to M-1, ::) +  lamda * one_end4 *  mkn(M, ::) - T
    val  ERR: Double = 0.5 * sum(sum((Q *:* Q), Axis._0))/N
    for  (i <-0 until k){
      var Is_1 = new Array[Double](N)
      for (j<- 0 until N ){
        Is_1(j) = S( is_Matrix(i,j).toInt  )
      }
      val Is = new DenseMatrix[Double](N,1,Is_1)
      val Tk = DenseMatrix.zeros[Double](M,N)
      for (j <- 0 until M){
        val ii= new ArrayBuffer[Int]
        var index_1: Int = 0
        for(o<-Is_1){
          if (o==(j+1).toDouble) {ii.append(index_1)}
          index_1=index_1+1
        }
        if (ii.length>0){
          for (oo<-0 until ii.length){
            Tk(j,ii(oo))=1
          }
        }
      }
      val m1: DenseMatrix[Double] = s_yong(i)
      val one_end5 = DenseMatrix.ones[Double](M,1)
      val m2 = Tk *:* (one_end5 * m1)
      val one_end6 = DenseMatrix.ones[Double](1,N)
      val m3 = one_end6 - m1
      val m = DenseMatrix.vertcat(m2, m3)
      val mm1 = (mk(M,::) /:/ m(M,::)).t.toDenseMatrix
      val H = one_end5 * mm1
      val mm2: DenseMatrix[Double] = (   mk(0 to M-1,::)- H *:* m (0 to M-1, ::) ) /:/  (m (0 to M-1, ::)  +  one_end5 * m(M,::))
      val v = ( mm2 + one_end5 * mm1  ) *:* Tk - mm2
      val DsK: DenseMatrix[Double] =  sum(v, Axis._0).t.toDenseMatrix - mm1
      val Dsm1 =   ((one_end5 * Kn) *:* v -  mk(0 to M-1,::) *:* (one_end5*DsK)) /:/  ( one_end5 * (Kn *:* Kn )  )
      val Dsm2 =   ((- Kn).t.toDenseMatrix  *:* mm1 - mk(M,::).t.toDenseMatrix *:* DsK) /:/ (Kn *:* Kn).t.toDenseMatrix
      val Ds: DenseMatrix[Double] =      sum(Q  *:*   (Dsm1 + lamda * one_end5 * Dsm2), Axis._0)  .t.toDenseMatrix
      Dsgama = Dsgama - gama.toDenseMatrix.t * (  Ds *:*  ds_Matrix(k-1,::).t.toDenseMatrix *:* m1 ) *:* Tk - gama.toDenseMatrix.t * (  Ds *:*  ds_Matrix(k-1,::).t.toDenseMatrix *:* m1 ) *:* Tk
    }
    val Dgama: Transpose[DenseVector[Double]] =   sum (Dsgama.t, Axis._0) * (1/N.toDouble)
    (ERR, Dgama)
  }

  def gamma_begin(train: ArrayBuffer[(Long, LabeledPoint)], neighs: Array[Array[Array[Double]]]): (Array[Array[Double]],DenseMatrix[Double],DenseVector[Double]) = {
    val Napp: Int =train.length
//  println(train(0).features)
    val input = new Array[Double](Napp*numFeatures)
    for(i<- 0 until Napp){
      for(j<- 0 until numFeatures){
        input(i*numFeatures+j)=train(i)._2.features(j)
      }
    }
    val X = new DenseMatrix[Double](Napp, numFeatures, input)
    val S= new Array[Double](Napp)  /** ii存储类别i在S中的下标*/

    for(i <- 0 until Napp) {S(i)=train(i)._2.label}
    val S_1 = new DenseMatrix[Double](1, Napp, S).toDenseVector
    var M_1: DenseVector[Double] = unique(S_1)
    var U = 0
    for(i<- M_1){
      U = U + 1
      for(j<- 0 until Napp){
        if (S(j) == i ){
          S(j) = U
        }
      }
    }
    val M: Int = M_1.length
    M_1 = DenseVector.tabulate( 1 to M)(pp=> pp)
    var Dm_i = new Array[Double](M)

    for(i <- M_1) {
      val ii= new ArrayBuffer[Int]  /** ii存储类别i在S中的下标*/
      var index_1: Int = 0
      for(j<-S){
        if (j==i) {ii.append(index_1)}
        index_1=index_1+1
      }  /** 相当于matlab中的find函数，将i在S中的下标记返回至 ArrayBuffer ii 中*/

      val Nii: Int = ii.length
      val x_4_4 = new Array[Double](Nii*numFeatures)
      for (i<- 0 until numFeatures){
        for(j <-0 until Nii){
          x_4_4(i*Nii+j)=train(ii(j))._2.features(i)
        }
      }
      val x_4 = new DenseMatrix[Double](Nii, numFeatures, x_4_4)
      val x_9 = new Array[Double](Nii * Nii)
      for (j<- 0 until Nii){
        val x_1 = new Array[Double](numFeatures)
        for {o<- 0 to numFeatures-1}{
          x_1(o)=train(ii(j))._2.features(o)
        }
        val x_1_d = DenseVector(x_1).t
        val x_2: DenseVector[Double] =DenseVector.ones[Double](Nii)
        val x_3 = x_2 * x_1_d
        val x_5 = (x_3-x_4).t *:* (x_3-x_4).t /** numfeatures * Nii 中*/
        val x_6: Transpose[DenseVector[Double]] = sum(x_5, Axis._0)
        val x_7: DenseVector[Double] = x_6.t /** Nii * 1 中*/
        val x_8: Transpose[DenseVector[Double]] = sqrt(x_7).t
       for(i<- 0 until Nii)
       {x_9(j*Nii+i)=x_8(i)}
      }
      var D = new DenseMatrix[Double](Nii,Nii,x_9)
      D=D.t
      Dm_i(i.toInt-1) = 1/(sum(D)/(Nii * Nii - Nii))
    }
  val gamm: Array[Double] = Dm_i
    val out = new Array[Array[Double]](2)
    out(0)=gamm
    out(1)=S
    (out, X,M_1)
  }



  def knnMembership[T](iter: Iterator[(Long, LabeledPoint)]): Iterator[(Long, LabeledPoint, Double)]  = {/** @此处修改*/
    var train = new ArrayBuffer[(Long, LabeledPoint)]
    while (iter.hasNext)
      train.append(iter.next)//在train的末尾追加元素，将迭代器中的labeledpoint放入train
    val size = train.length//训练集的大小
    println(size)
    //println(numPartitionMap)
    var knnMemb: KNN = new KNN(train, k, Distance.Euclidean, numClass)//这个KNN是如何能直接拿过来使用的过来的，应该是都在LHS_FKNN的这个包里面，knnMemb是二维数组
    var neigh = new Array[Array[Array[Double]]](size)//neigh是一个包含了训练集大小的元素的三维数组，每个元素都是一个二维数组
    var result: Array[Array[Double]] = new Array[Array[Double]](size)
    /** @此处修改！！：注释掉了下面的内容*/
    for (i <- 0 until size) {
      if (i%100==0){println(i)}
      neigh(i) = knnMemb.neighbors(train(i)._2.features)
    }

//val L=gamma_learn(train,neigh)
    val KKK: (Array[Array[Double]], DenseMatrix[Double], DenseVector[Double]) = gamma_begin(train,neigh)
    val L_2: Array[Array[Double]] =KKK._1
    val X: DenseMatrix[Double] = KKK._2
    val M_1: DenseVector[Double] = KKK._3
    val L_1: Array[(Long, LabeledPoint, Double)] = gamma_learn(train, neigh, L_2(1), X , L_2(0), M_1)
    L_1.iterator
  }
}

/** @此处修改注释掉了对象下面的所有内容*/
object LHS_FkNN {
  /**
   * @brief Initial setting necessary.
   *
   * @param train Data that iterate the RDD of the train set
   * @param k number of neighborsThe test set in a broadcasting
   * @param distanceType MANHATTAN = 1 ; EUCLIDEAN = 2
   * @param numClass Number of classes of the output variable
   * @param numFeatures Number of input variables
   * @param numPartitionMap Number of partition. Number of map tasks
   */
  def LHS_Membership(train: RDD[(Long, LabeledPoint)], k: Int, distanceType: Int, numClass: Int, numFeatures: Int, numPartitionMap: Int) = {
    new LHS_FkNN(train, k, distanceType, numClass, numFeatures, numPartitionMap).LHS_Membership()
  }
}