package org.apache.spark.mllib.classification.kNN_IS

import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.Vector
//import org.apache.spark.ml.feature.LabeledPoint
import scala.collection.mutable.ArrayBuffer
import breeze.linalg._
import breeze.numerics._
import breeze.stats.distributions.Rand
import org.apache.spark.mllib.linalg
/** K Nearest Neighbors algorithms. 
 *
 * @param train Traning set
 * @param k Number of neighbors
 * @param distanceType Distance.Manhattan or Distance.Euclidean
 * @param numClass Number of classes
 * @author sergiogvz
 */
class KNN(val train: ArrayBuffer[(Long, LabeledPoint, Double)], val k: Int, val distanceType: Distance.Value, val numClass: Int) {

  /** Calculates the k nearest neighbors.
   *
   * @param x Test sample
   * @return Distance and class of each nearest neighbors
   */
  def neighbors(x: Vector): Array[Array[Float]] = {
    var nearest = Array.fill(k)(-1)
    var distA = Array.fill(k)(0.0f)
    val size = train.length

    for (i <- 0 until size) { //for instance of the training set
      var dist: Float = Distance(x, train(i)._2.features, distanceType)

      if (dist > 0d) {
        var stop = false
        var j = 0
        while (j < k && !stop) { //Check if it can be inserted as NN
          if (nearest(j) == (-1) || dist <= distA(j)) {
            for (l <- ((j + 1) until k).reverse) { //for (int l = k - 1; l >= j + 1; l--)
              nearest(l) = nearest(l - 1)
              distA(l) = distA(l - 1)
            }
            nearest(j) = i
            distA(j) = dist
            stop = true
          }
          j += 1
        }
      }
    }

    var out: Array[Array[Float]] = new Array[Array[Float]](k)
    for (i <- 0 until k) {
      out(i) = new Array[Float](3)
      out(i)(0) = distA(i)
      out(i)(1) = train(nearest(i))._2.label.toFloat
      out(i)(2) =  train(nearest(i))._3.toFloat
    }

    out
  }




}

/** Factory to compute the distance between two instances.
 *
 * @author sergiogvz
 */
object Distance extends Enumeration {
  val Euclidean, Manhattan, DTW, DDTW, FDTW  = Value

  /** Computes the (Manhattan or Euclidean) distance between instance x and instance y.
   * The type of the distance used is determined by the value of distanceType.
   *
   * @param x instance x
   * @param y instance y
   * @param distanceType type of the distance used (Distance.Euclidean or Distance.Manhattan)
   * @return Distance
   */
  def apply(x: Vector, y: Vector, distanceType: Distance.Value) = {
    distanceType match {
      case Euclidean => euclidean(x, y)
      case Manhattan => manhattan(x, y)
      case DTW => DTW(x, y)
      case DDTW => DDTW(x, y)
      case FDTW => FDTW(x, y)
      case _         => euclidean(x, y)
    }
  }

  /** Computes the Euclidean distance between instance x and instance y.
   * The type of the distance used is determined by the value of distanceType.
   *
   * @param x instance x
   * @param y instance y
   * @return Euclidean distance
   */
  private def euclidean(x: Vector, y: Vector) = {
    var sum = 0.0
    val size = x.size

    for (i <- 0 until size) sum += (x(i) - y(i)) * (x(i) - y(i))

    Math.sqrt(sum).toFloat

  }

  private def DTW(x: Vector, y: Vector): Float = {
    var sum: Double = 0.0
    val size = x.size
    val xxx: Array[Double] = x.toArray
    val xx_1: DenseMatrix[Double] = DenseMatrix(xxx)
    var X =DenseMatrix.vertcat(xx_1,xx_1)

    val yyy: Array[Double] = y.toArray
    val yy_1: DenseMatrix[Double] = DenseMatrix(yyy).t
    var Y =DenseMatrix.horzcat(yy_1,yy_1)


    for (i <- 1 until size - 1) {
      X = DenseMatrix.vertcat(X,xx_1)
      Y = DenseMatrix.horzcat(Y,yy_1)
    }
    val d = (X-Y):*(X-Y)
    val D=DenseMatrix.zeros[Double](size,size)
    D(0,0)=d(0,0)
    for(i <- 1 until size) D(i,1)=d(i,1)+D(i-1,1)

    for(i <- 1 until size) D(1,i)=d(1,i)+D(1,i-1)

    for (i <- 1 until size)
    {
      for (j <- 1 until size){
        D(i,j) = d(i,j) + min ( D( i-1, j ), D( i-1, j-1 ),D(i, j-1 ) )
      }
    }

    D( size-1,size-1).toFloat

  }


  private def FDTW(x: Vector, y: Vector): Float = {
    var sum: Double = 0.0
    val size = x.size
    val xxx: Array[Double] = x.toArray
    val xx_1: DenseMatrix[Double] = DenseMatrix(xxx)
    var X =DenseMatrix.vertcat(xx_1,xx_1)

    val yyy: Array[Double] = y.toArray
    val yy_1: DenseMatrix[Double] = DenseMatrix(yyy).t
    var Y =DenseMatrix.horzcat(yy_1,yy_1)


    for (i <- 1 until size - 1) {
      X = DenseMatrix.vertcat(X,xx_1)
      Y = DenseMatrix.horzcat(Y,yy_1)
    }
    val d = (X-Y):*(X-Y)
    val D=DenseMatrix.zeros[Double](size,size)
    D(0,0)=d(0,0)
    D(1,0)=d(1,0)+D(0,0)
    D(0,1)=d(0,1)+D(0,0)

    for (i <- 1 to size -1 )
    {
      if (i==1){ D(1,1)=d(1,1)+ min ( D( i-1, 1 ), D( i-1, 0 ),D(i, 0 ))}
      if (i>1 & i< 23){
        for (j  <- i -1 to i+1) {
          if (j == i) {
            D(i, j) = d(i, i) + min(D(i - 1, j), D(i - 1, j - 1), D(i, j - 1))
          }
          if (j == i - 1) {
            D(i, j) = d(i, j) + min(D(i - 1, j), D(i - 1, j - 1))
          }
          if (j == i + 1) {
            D(i, j) = d(i, j) + min(D(i - 1, j - 1), D(i, j - 1))
          }
        }
      }
      if (i==23){
        D(i,22)=d(i,22) + min(D(22,21),D(22,22) )
        D(i,23)=d(i,23) + min(D(22,22),D(23,22),D(22,23))
      }
    }

    D( size-1,size-1).toFloat

  }
  /** Computes the Manhattan distance between instance x and instance y.
   * The type of the distance used is determined by the value of distanceType.
   *
   * @param x instance x
   * @param y instance y
   * @return Manhattan distance
   */
  private def manhattan(x: Vector, y: Vector) = {
    var sum = 0.0
    val size = x.size

    for (i <- 0 until size) sum += Math.abs(x(i) - y(i))

    sum.toFloat
  }

  private def DDTW(x: Vector, y: Vector): Float = {
    var sum: Double = 0.0
    val size = x.size
    val xxx: Array[Double] = x.toArray
    val yyy: Array[Double] = y.toArray
    val k1 = xxx
    val k2 = yyy
    for (i <- 0 until size) {
      if (i==1){
        k1(i)=xxx(2)-xxx(1)
        k2(i)=yyy(2)-yyy(1)
      }
      if (i>1 & i< size-1) {
        k1(i)=0.5*(xxx(i)-xxx(i-1)+0.5*(xxx(i+1)-xxx(i-1)))
        k2(i)=0.5*(yyy(i)-yyy(i-1)+0.5*(yyy(i+1)-yyy(i-1)))
      }
      if (i==size-1) {
        k1(i)=xxx(i)-xxx(i-1)
        k2(i)=yyy(i)-yyy(i-1)
      }
    }




    val xx_1: DenseMatrix[Double] = DenseMatrix(k1)
    var X =DenseMatrix.horzcat(xx_1,xx_1)


    val yy_1: DenseMatrix[Double] = DenseMatrix(k2).t
    var Y =DenseMatrix.vertcat(yy_1,yy_1)


    for (i <- 0 until size - 1) {
      X = DenseMatrix.horzcat(X,xx_1)
      Y = DenseMatrix.vertcat(Y,yy_1)
    }
    val d = (X-Y):*(X-Y)
    val D=DenseMatrix.zeros[Double](size,size)
    D(0,0)=d(0,0)
    for(i <- 1 until size) D(i,1)=d(i,1)+D(i-1,1)

    for(i <- 1 until size) D(1,i)=d(1,i)+D(1,i-1)

    for (i <- 1 until size)
    {
      for (j <- 1 until size){
        D(i,j) = d(i,j) + min ( D( i-1, j ), D( i-1, j-1 ),D(i, j-1 ) )
      }
    }

    D( size-1,size-1).toFloat

  }

}