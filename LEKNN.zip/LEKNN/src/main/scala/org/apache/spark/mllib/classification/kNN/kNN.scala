package org.apache.spark.mllib.classification.LHS_FkNN


import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.Vector
//import org.apache.spark.ml.feature.LabeledPoint
import scala.collection.mutable.ArrayBuffer
import breeze.linalg._
import breeze.numerics._
import breeze.stats.distributions.Rand
import org.apache.spark.mllib.linalg


class  KNN(val train: ArrayBuffer[(Long, LabeledPoint)], val k: Int, val distanceType: Distance.Value, val numClass: Int) {

  /** @此处修改了输出的类型*/
  //def neighbors(x: Vector): Array[Array[Float]] = {//x是查询变量
  def neighbors(x: Vector): Array[Array[Double]] = {//x是查询变量
    
  var nearest: Array[Int] = Array.fill(k)(-1)//初始化数组（-1，-1，-1，-1，-1）k个-1
    
  var distA = Array.fill(k)(0.0d)//初始化数组（0，0，0，0，0）k个0
    
  val size = train.length//训练集的大小

    
  for (i <- 0 until size) { //for instance of the training set.每次都计算查询变量到一个训练集中的点的距离
      
  var dist: Double = Distance(x, train(i)._2.features, distanceType)

    if (dist > 0d) {

  var stop = false
       
  var j = 0
        
  while (j < k && !stop) { //Check if it can be inserted as NN
         
   if (nearest(j) == (-1) || dist <= distA(j)) {
           
   for (l <- ((j + 1) until k).reverse) {//reverse代表的是从后向前遍历数组，每次都把大的向后推，只有比当前距离小的距离值可以进入判断语句
              nearest(l) = nearest(l - 1)
              distA(l) = distA(l - 1)
            }
            nearest(j) = i//nearest存储的是这个查询变量的近邻的下标
            distA(j) = dist//distA是对应的距离，这两个变量都是数组
            stop = true
          }
          j += 1
        }
      }
    }
    /** @此处修改了out的类型*/
    //var out: Array[Array[Float]] = new Array[Array[Float]](k)
    var out: Array[Array[Double]] = new Array[Array[Double]](k)
    for (i <- 0 until k) {
      /** @此处修改了out的类型*/
      //out(i) = new Array[Float](3)//out是一个二维数组，其中每一个元素都是一个包含两个元素的数组
      out(i) = new Array[Double](3)
      out(i)(0) = distA(i)//第一个元素是距离
      out(i)(1) = train(nearest(i))._2.label.toDouble+1//第二个元素是这个近邻的label
      out(i)(2) = nearest(i)//第三个元素是这个近邻的index，下标
    }

    out//是对于查询变量x来说Array(Array(距离，标签,index)，...这样的K个小Array)
  }

}


/**
 * Factory to compute the distance between two instances.
 * @author sergiogvz
 */
object Distance extends Enumeration {
  val Euclidean, Manhattan = Value

  /**
   * @brief Computes the distance between instance x and instance y. The type of the distance used is determined by the value of distanceType.
   *
   * @param x instance x
   * @param y instance y
   * @param distanceType type of the distance used (Distance.Euclidean or Distance.Manhattan)
   */
  //def apply(x: Vector, y: Vector, distanceType: Distance.Value) = {
  /** @此处修改了out的类型*/
    def apply(x: Vector, y: Vector, distanceType: Distance.Value) = {
    distanceType match {
      case Euclidean => euclidean(x, y)
      case Manhattan => manhattan(x, y)
      case _         => euclidean(x, y)
    }
  }

  private def euclidean(x: Vector, y: Vector) = {
    var sum = 0.0
    val size = x.size

    for (i <- 0 until size) sum += (x(i) - y(i)) * (x(i) - y(i))

    //Math.sqrt(sum).toFloat
    Math.sqrt(sum).toDouble

  }

  private def manhattan(x: Vector, y: Vector) = {
    var sum = 0.0
    val size = x.size

    for (i <- 0 until size) sum += Math.abs(x(i) - y(i))

    //sum.toFloat
    sum.toDouble
  }

}