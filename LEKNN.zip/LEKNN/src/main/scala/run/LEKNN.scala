package org.apache.spark.run

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SparkSession}
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.classification.LHS_FkNN.{Distance, KNN, LHS_FkNN}
import org.apache.spark.mllib.linalg.Matrix
import scala.collection.mutable.ListBuffer
import org.apache.log4j.Logger
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.classification.kNN_IS.kNN_IS
import org.apache.spark.rdd.RDD
import utils.keel.KeelParser




object REKNN extends Serializable {
  var sc: SparkContext = null
  def main (arg: Array[String]): Unit = {
    Logger.getLogger("org.apache.spark").setLevel(Level.WARN)
    Logger.getLogger("org.eclipse.jetty.server").setLevel(Level.OFF)
    //val pathTrain = "file:///D:/sparkthing/EPS/dataset/CONTYPENO29.data"
    val pathTrain = "file:///D:/sparkthing/SPARK-EKNN/dataset/page-blocks-tra.data"
    val pathTest = "file:///D:/sparkthing/SPARK-EKNN/dataset/page-blocks-tst.data"
    val pathHeader = "file:///D:/sparkthing/SPARK-EKNN/dataset/page-blocks.header"
    val pathOutput = "file:///D:/sparkthing/SPARK-EKNN/dataset/OUT_page"
      val K = 3

    val distanceType = 2
    val numPartition = 50
    val numClasses= 5
    val numFeatures= 10
    val numIterations = 1
    var maxWeight = 10.0
    val numReduces = 1

    val conf = new SparkConf().setAppName("EKNN").setMaster("local[*]")
    sc = new SparkContext(conf)
    val spark = SparkSession.builder().master("local[*]").appName("EKNN").getOrCreate()
    val converter = new KeelParser(sc, pathHeader)


    val train: RDD[(Long, LabeledPoint)] = sc.textFile(pathTrain: String, numPartition).map(line => converter.parserToLabeledPoint(line)).zipWithIndex().map(line=>(line._2,line._1)).persist
    val test: RDD[LabeledPoint] = sc.textFile(pathTest: String, numPartition).map(line => converter.parserToLabeledPoint(line)).persist
    val timeBeg = System.nanoTime
    var result: LHS_FkNN = LHS_FkNN.LHS_Membership(train, K, 2, numClasses, numFeatures, numPartition)
    val train_result: RDD[(Long, LabeledPoint, Double)] = result.getTrainFuzzified
    train_result.count


    val knn: kNN_IS = kNN_IS.setup(train_result, test, K, distanceType, numClasses, numFeatures, numPartition, numReduces, numIterations, maxWeight)
    var predictions: RDD[(Double, Double)] = knn.predict()
    val metrics = new MulticlassMetrics(predictions)
    val accuracy = metrics.accuracy
    val cm: Matrix = metrics.confusionMatrix
    val weight_precision = metrics.weightedPrecision
    val weight_F1 = metrics.weightedFMeasure
    val binaryMetrics = new BinaryClassificationMetrics(predictions)
    val AUC = binaryMetrics.areaUnderROC.toString()

    val timeEnd = System.nanoTime
    var writerReport = new ListBuffer[String]
    writerReport += "***Report.txt ==> Contain: Confusion Matrix; Precision; Total Runtime***\n"
    writerReport += "@ConfusionMatrix\n" + cm
    writerReport += "\n@Accuracy\n" + accuracy
    writerReport += "\n@AUC\n" + AUC
    writerReport += "\n@precision\n" + weight_precision
    writerReport += "\n@F1\n" + weight_F1
    writerReport += "\n@PredictionRuntime\n" + (timeEnd - timeBeg) / 1e9
    val Report = sc.parallelize(writerReport, 1)
    Report.saveAsTextFile(pathOutput + "/Report_result")




  }
}
